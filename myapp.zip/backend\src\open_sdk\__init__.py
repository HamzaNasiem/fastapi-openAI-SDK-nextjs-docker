def main() -> None:
    print("Hello from open-sdk!")
